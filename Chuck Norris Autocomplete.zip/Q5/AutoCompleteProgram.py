import tkinter as tk
from tkinter import ttk, scrolledtext
import sys
import logging
from traceback import format_list
import json

# Rest of the imports and logging setup remain the same...

class SearchApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Auto-Complete Trie")
        self.root.geometry("1000x600")
        self.root.resizable(False, False)

        self.joke_filepath = 'Input.txt' 
        self.trie = self.construct_trie() #Pre-build the trie

        try:
            # Add main title at the top
            self.title_label = ttk.Label(root, text="Chuck Norris Joke Auto-Complete",
                                       font=('Helvetica', 16, 'bold'))
            self.title_label.pack(pady=30)

            # Create a main container for centered content
            main_container = ttk.Frame(root)
            main_container.pack(expand=True, fill=tk.BOTH, padx=20)

            # First row: Auto-Complete section
            self.search_frame = ttk.Frame(main_container)
            self.search_frame.pack(pady=20, fill=tk.X)

            # Label for auto-complete
            self.auto_complete_label = ttk.Label(self.search_frame, text="Auto-Complete demo:",
                                               font=('Helvetica', 10))
            self.auto_complete_label.pack(side=tk.LEFT, padx=(0, 10))

            self.search_input = ttk.Entry(self.search_frame, width=100)
            self.search_input.pack(side=tk.LEFT, expand=True, fill=tk.X)
            self.search_input.bind('<KeyRelease>', self.on_input_change)

            self.search_input.bind('<Return>', self.add_user_joke)

            # Search output display area
            self.display_text = scrolledtext.ScrolledText(main_container, height=5, width=120)
            self.display_text.pack(pady=10, fill=tk.X)

            # Find frame with input and button
            self.find_frame = ttk.Frame(main_container)
            self.find_frame.pack(pady=20, fill=tk.X)

            # Label for search word
            self.search_label = ttk.Label(self.find_frame, text="Search word:",
                                        font=('Helvetica', 10))
            self.search_label.pack(side=tk.LEFT, padx=(0, 10))

            self.find_input = ttk.Entry(self.find_frame, width=100)
            self.find_input.pack(side=tk.LEFT, expand=True, fill=tk.X, padx=(0, 10))

            self.find_button = ttk.Button(self.find_frame, text="Search",
                                        command=self.search, width=20)
            self.find_button.pack(side=tk.LEFT)

            # Find results display
            self.find_display = scrolledtext.ScrolledText(main_container, height=5, width=120)
            self.find_display.pack(pady=10, fill=tk.X)

            # Bottom buttons frame
            self.button_frame = ttk.Frame(main_container)
            self.button_frame.pack(pady=30)

            self.export_button = ttk.Button(self.button_frame, text="Export Tree",
                                          command=self.export_tree, width=20)
            self.export_button.pack(side=tk.LEFT, padx=10)

            self.quit_button = ttk.Button(self.button_frame, text="Quit",
                                        command=self.quit_app, width=20)
            self.quit_button.pack(side=tk.LEFT, padx=10)

        except Exception as e:
            logging.error(f"Error in initialization: {str(e)}")
            raise
.


    #Build a full trie by "adding" each line in the input to the root
    def construct_trie(self):
        root = TrieNode()
        with open(self.joke_filepath, "r", encoding="utf-8") as file:
            for line in file:
                line = self.format_line(line)
                root.add(line)
        return root

    #Make sure line is in english lowercase, with at most 1 consecutive space
    def format_line(self, line):
        line = self.HE_to_ENG(line)
        line = line.lower()
        legalABC='abcdefghijklmnopqrstuvwxyz '
        text=''
        last_was_space = True
        for ch in line:
            if ch=='\n': # Newline detected: Replace with ‘space’
                ch=' '
            if ch in legalABC:
                if ch!=" ":
                    text= text + ch
                    last_was_space = False
                if ch==" " and last_was_space==False:
                    # Keeps only one space when encounters n-spaces
                    text= text + ch
                    last_was_space = True
        return text
        
    #Map hebrew letters to english ones, according to keyboard position
    def HE_to_ENG(self, line):
        mapping = {'/': 'q', "'": 'w', 'ק':'e', 'ר':'r', 'א':'t', 'ט':'y', 'ו':'u', 'ן':'i', 'ם':'o', 'פ':'p', 
                   'ש':'a', 'ד':'s', 'ג':'d', 'כ':'f', 'ע':'g', 'י':'h', 'ח':'j', 'ל':'k', 'ך':'l', 
                    'ז':'z', 'ס':'x', 'ב':'c', 'ה':'v', 'נ':'b', 'מ':'n', 'צ':'m' }
        output = ""
        for ch in line:
            if ch in mapping:
                output = output + mapping[ch]
            else:
                output = output + ch
        return output
    
    def compute_auto_complete(self, current_text):
        try:
            # SHMULIK: Enter point for computing auto complete list, while current_text is what you see in the input text box
            current_text = self.format_line(current_text)
            string_info = [] #A list of pairs (string, num of ocurrences)
            curr_node = self.trie
            for ch in current_text: #traverse the tree according to the given string
                if ch in curr_node.edges:
                    curr_node = curr_node.edges[ch]
                else:
                    return ["No results"] #If we reach a 'dead end', that means no such joke exists
            curr_node.traverse(string_info) #Fill string_frequencies with all possible jokes and their frequencies
            auto_complete_result = self.process_list(string_info)

            return auto_complete_result

        except Exception as e:
            logging.error(f"Error in computing auto complete: {str(e)}")


    def process_list(self, input_list):
        user_list = [x for x in input_list if x[2] == True]
        non_user_list = [x for x in input_list if x[2] == False]

        user_list = [x[0] for x in sorted(user_list, key=lambda x: x[1], reverse=True)]
        non_user_list = [x[0] for x in sorted(non_user_list, key=lambda x: x[1], reverse=True)]
        return user_list[:3] + non_user_list

    def on_input_change(self, event):
        try:
            current_text = self.search_input.get()
            # Create a list with the text twice
            display_list = self.compute_auto_complete(current_text)

            # Clear previous content
            self.display_text.delete('1.0', tk.END)

            # Insert each item from the list on a new line
            for item in display_list:
                self.display_text.insert(tk.END, f"{item}\n")

        except Exception as e:
            logging.error(f"Error in input change handler: {str(e)}")

    # Add the joke currently written in the autocomplete bar to the trie
    def add_user_joke(self, event):
        current_text = self.format_line(self.search_input.get())
        self.trie.add(joke = current_text, made_by_user = True)
        display_list = self.compute_auto_complete(current_text)

    # Search the input document for all jokes with a given prefix
    def perform_search(self, search_text):
        try:
            search_text = self.format_line(search_text)
            output_list = []
            with open(self.joke_filepath, "r", encoding="utf-8") as file:
                for line in file:
                    if search_text in line.lower(): #don't distinguish between upper/lower cases
                        output_list.append(line)
            return list(set(output_list)) #remove duplicates and output

        except Exception as e:
            logging.error(f"Error in input perform_search: {str(e)}")
            return []

    # Display a search's result
    def search(self):
        try:
            search_text = self.find_input.get()
            # Create a list with the text twice
            display_list = self.perform_search(search_text)

            # Clear previous content
            self.find_display.delete('1.0', tk.END)

            # Insert each item from the list on a new line
            for item in display_list:
                self.find_display.insert(tk.END, f"{item}\n")

        except Exception as e:
            logging.error(f"Error in search function: {str(e)}")
    
    # Dump the tree as a Json file
    def export_tree(self):
        try:
            trie_dict =self.trie.to_dict()
            with open("TreeDump.json", "w", encoding="utf-8") as json_file:
                json.dump(trie_dict, json_file, indent = 4)
        except Exception as e:
            logging.error(f"Error in export tree function: {str(e)}")

    def quit_app(self):
        try:
            self.root.quit()
            sys.exit(0)
        except Exception as e:
            logging.error(f"Error in quit function: {str(e)}")
            sys.exit(1)

# A prefix-tree (trie), given a prefix, can perform a traversal and return all strings starting in that prefix
class TrieNode:
    def __init__(self):
         self.curr_string = ""
         self.count = 0
         self.edges = {}
         self.user_tag = False
    
    # Add the joke to the trie, incrementing each node in our path.
    def add(self, joke, index = 0, made_by_user = False):
        if index >= len(joke): # We finished the joke
            self.user_tag = made_by_user
            return
        curr_char = joke[index]
        index+=1
        if curr_char not in self.edges: #No pre-existing edge for the current character
            self.edges[curr_char] = TrieNode()
        next_node = self.edges[curr_char]
        next_node.count+=1
        next_node.curr_string = joke[:index]
        next_node.add(joke, index, made_by_user)

    def traverse(self, input_list):
        if len(self.edges) > 0:
            for key, value in self.edges.items():
                value.traverse(input_list)
        else: #we are a leaf, thus a complete joke
            input_list.append((self.curr_string, self.count, self.user_tag))

    def to_dict(self, first_word = True): #for Json dumping
        full_word = False
        full_joke = False
        if len(self.edges) == 0:
            full_joke = True
        elif ' ' in self.edges and first_word:
            first_word = False
            full_word = True
        node_dict = {
         'curr_string': self.curr_string,
         'count': self.count,
         'Full word': full_word,
         'Full joke': full_joke,
         'edges': {}
        }
        for key, child_node in self.edges.items():
            node_dict['edges'][key] = child_node.to_dict(first_word)
        return node_dict

def main():
    try:
        root = tk.Tk()
        app = SearchApp(root)
        root.mainloop()
    except Exception as e:
        logging.error(f"Error in main: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()